#include "motorcycle.h"

Motorcycle::Motorcycle(Vehicle vehicle)
    :Vehicle(vehicle)
{
}
