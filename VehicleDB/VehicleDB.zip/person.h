#ifndef PERSON_H
#define PERSON_H

#include <string>

// Surprisingly it's just a string. It helps the abstraction.
// In future this can easily become a class.
typedef std::string Person;

#endif // PERSON_H
