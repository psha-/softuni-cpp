Developed on Ubuntu with QtCreator, c++11. Please use "make" in one of the build-* folders.
