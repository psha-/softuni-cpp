#include "truck.h"

Truck::Truck(Vehicle vehicle)
    : Vehicle(vehicle)
{
}
