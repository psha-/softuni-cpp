#include "car.h"

Car::Car(Vehicle vehicle)
    :Vehicle(vehicle)
{
}
